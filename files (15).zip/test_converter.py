import json
import csv
from converter import csv_to_json, json_to_csv, _coerce


def test_coerce_int():
    assert _coerce("42") == 42


def test_coerce_float():
    assert _coerce("3.14") == 3.14


def test_coerce_bool_true():
    assert _coerce("true") is True


def test_coerce_bool_false():
    assert _coerce("False") is False


def test_coerce_null():
    assert _coerce("") is None
    assert _coerce("null") is None


def test_coerce_string_passthrough():
    assert _coerce("hello") == "hello"


def test_csv_to_json_basic(tmp_path):
    csv_file = tmp_path / "in.csv"
    csv_file.write_text("name,age,active\nAda,30,true\nGrace,,false\n", encoding="utf-8")

    json_file = tmp_path / "out.json"
    csv_to_json(str(csv_file), str(json_file))

    data = json.loads(json_file.read_text(encoding="utf-8"))
    assert data == [
        {"name": "Ada", "age": 30, "active": True},
        {"name": "Grace", "age": None, "active": False},
    ]


def test_csv_to_json_unicode(tmp_path):
    csv_file = tmp_path / "in.csv"
    csv_file.write_text("name,city\nZoë,São Paulo\n", encoding="utf-8")

    json_file = tmp_path / "out.json"
    csv_to_json(str(csv_file), str(json_file))

    data = json.loads(json_file.read_text(encoding="utf-8"))
    assert data == [{"name": "Zoë", "city": "São Paulo"}]


def test_json_to_csv_basic(tmp_path):
    json_file = tmp_path / "in.json"
    json_file.write_text(
        json.dumps([{"name": "Ada", "age": 30}, {"name": "Grace", "age": 40}]),
        encoding="utf-8",
    )

    csv_file = tmp_path / "out.csv"
    json_to_csv(str(json_file), str(csv_file))

    with open(csv_file, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows == [
        {"name": "Ada", "age": "30"},
        {"name": "Grace", "age": "40"},
    ]


def test_json_to_csv_missing_fields(tmp_path):
    """Rows with different keys should still produce a valid CSV with blanks."""
    json_file = tmp_path / "in.json"
    json_file.write_text(
        json.dumps([{"name": "Ada", "age": 30}, {"name": "Grace", "city": "Boston"}]),
        encoding="utf-8",
    )

    csv_file = tmp_path / "out.csv"
    json_to_csv(str(json_file), str(csv_file))

    with open(csv_file, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows == [
        {"name": "Ada", "age": "30", "city": ""},
        {"name": "Grace", "age": "", "city": "Boston"},
    ]


def test_json_to_csv_bool_serialization(tmp_path):
    json_file = tmp_path / "in.json"
    json_file.write_text(json.dumps([{"active": True}, {"active": False}]), encoding="utf-8")

    csv_file = tmp_path / "out.csv"
    json_to_csv(str(json_file), str(csv_file))

    with open(csv_file, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows == [{"active": "true"}, {"active": "false"}]


def test_round_trip_preserves_data(tmp_path):
    original = [
        {"id": 1, "name": "Ada", "score": 9.5, "active": True},
        {"id": 2, "name": "Grace", "score": 8.0, "active": False},
    ]
    json_file = tmp_path / "a.json"
    json_file.write_text(json.dumps(original), encoding="utf-8")

    csv_file = tmp_path / "b.csv"
    json_to_csv(str(json_file), str(csv_file))

    json_file_2 = tmp_path / "c.json"
    csv_to_json(str(csv_file), str(json_file_2))

    round_tripped = json.loads(json_file_2.read_text(encoding="utf-8"))
    assert round_tripped == original
