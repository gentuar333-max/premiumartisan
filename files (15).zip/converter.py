"""
csv_json_converter
-------------------
Small bidirectional CSV <-> JSON converter.

Functions
---------
csv_to_json(csv_path, json_path) -> None
    Reads a CSV file and writes its contents as a JSON array of objects.
    Values are type-coerced: integers, floats, booleans, and null are
    detected and converted from their string representation.

json_to_csv(json_path, csv_path) -> None
    Reads a JSON array of flat objects and writes it as CSV. The column
    header is the union of all keys found across all objects, so rows
    with missing fields are simply left blank in that column.

Usage
-----
    python converter.py csv2json input.csv output.json
    python converter.py json2csv input.json output.csv
"""

import csv
import json
import sys
from pathlib import Path
from typing import Any


def _coerce(value: str) -> Any:
    """Convert a raw CSV string into the most appropriate JSON type."""
    if value == "":
        return None
    lowered = value.strip().lower()
    if lowered == "true":
        return True
    if lowered == "false":
        return False
    if lowered == "null":
        return None
    try:
        as_int = int(value)
        return as_int
    except ValueError:
        pass
    try:
        as_float = float(value)
        return as_float
    except ValueError:
        pass
    return value


def csv_to_json(csv_path: str, json_path: str) -> None:
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        rows = [{key: _coerce(val) for key, val in row.items()} for row in reader]

    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(rows, f, indent=2, ensure_ascii=False)


def json_to_csv(json_path: str, csv_path: str) -> None:
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    if not isinstance(data, list):
        raise ValueError("Expected a JSON array of objects at the top level")

    fieldnames: list[str] = []
    for row in data:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in data:
            normalized = {}
            for key in fieldnames:
                value = row.get(key, "")
                if value is None:
                    normalized[key] = ""
                elif isinstance(value, bool):
                    normalized[key] = "true" if value else "false"
                else:
                    normalized[key] = value
            writer.writerow(normalized)


def main() -> None:
    if len(sys.argv) != 4 or sys.argv[1] not in ("csv2json", "json2csv"):
        print("Usage: python converter.py <csv2json|json2csv> <input> <output>")
        sys.exit(1)

    mode, src, dst = sys.argv[1], sys.argv[2], sys.argv[3]
    Path(dst).parent.mkdir(parents=True, exist_ok=True)

    if mode == "csv2json":
        csv_to_json(src, dst)
    else:
        json_to_csv(src, dst)

    print(f"Wrote {dst}")


if __name__ == "__main__":
    main()
