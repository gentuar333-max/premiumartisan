# CSV <-> JSON Converter

A small, dependency-free bidirectional converter between CSV and JSON.

## Features

- **Type coercion**: numbers, booleans, and empty values are converted to
  their proper JSON types (`int`, `float`, `bool`, `null`) instead of staying
  as strings.
- **Unicode-safe**: non-ASCII characters are preserved correctly in both
  directions.
- **Handles inconsistent rows**: when converting JSON to CSV, objects with
  different keys still produce a valid CSV (missing fields are left blank).
- **No external dependencies**: uses only Python's standard library.

## Usage

```bash
python converter.py csv2json input.csv output.json
python converter.py json2csv input.json output.csv
```

## Example

`input.csv`:

```csv
name,age,active
Ada,30,true
Grace,,false
```

`output.json`:

```json
[
  { "name": "Ada", "age": 30, "active": true },
  { "name": "Grace", "age": null, "active": false }
]
```

## Tests

Run the test suite with:

```bash
pytest test_converter.py -v
```

12 tests covering type coercion, unicode handling, missing fields, boolean
serialization, and full round-trip data integrity (JSON -> CSV -> JSON
reproduces the original data exactly).
